package com.cisco.appraisal_webapp.controller;

import java.io.File;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cisco.appraisal_webapp.dao.ReviewCRUDImpl;
import com.cisco.appraisal_webapp.model.AppraisalData;

@CrossOrigin

/**
 * RestController has both @Controller + @ResponseBody
 */
@RestController
@RequestMapping("/review")
public class AppraisalWebAppController {
	
	ReviewCRUDImpl re = new ReviewCRUDImpl();
	
	@RequestMapping(value ="/getReviewData", produces = "application/json")
	public ResponseEntity<AppraisalData> getandsaveData ()throws JAXBException {
		JAXBContext context = JAXBContext.newInstance(AppraisalData.class);
		Unmarshaller unmarshaller = context.createUnmarshaller();
		Object obj = unmarshaller.unmarshal(new File("C://Users//lokesh.m//Desktop//test//apprasial_data.xml"));
		
		if(obj instanceof AppraisalData) {
			AppraisalData ReviewQuestions = (AppraisalData) obj;
			System.out.println(ReviewQuestions);
			return new ResponseEntity<AppraisalData>(ReviewQuestions, HttpStatus.OK);
		} else {
			return new ResponseEntity<AppraisalData>(HttpStatus.BAD_GATEWAY);
		}
		
	}
}

