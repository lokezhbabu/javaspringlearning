(function () {
    "use strict";
    angular
        .module("appraisalReview")
        .controller("employeeController", employeeController);

        employeeController.$inject = ["employeeGetSet", "reviewOperation", "$state"];
        function employeeController (employeeGetSet, reviewOperation, $state) {
            var vm =  this;
            vm.check = "employeeController via module is loaded";
            vm.getServiceData = getServiceData;
            vm.getReviewData = getReviewData;
            vm.jQueryEventTrigger = jQueryEventTrigger;
            vm.logOut = logOut;
            vm.employeeData = "";
            vm.reviewQuestion= "";
            vm.res = [];

            getServiceData();
            jQueryEventTrigger();

            function jQueryEventTrigger() {
                $('.ui.accordion').accordion();
                $('.ui.sidebar').sidebar('toggle');
            }

            function getServiceData() {
                vm.employeeData = employeeGetSet.getEmployeeData();                
                // if(vm.employeeData == ""){
                //     $state.go('root.home');
                // }
            }

            function getReviewData() {
                reviewOperation.getReviewQuestion().then(successResponse);
            }

            function logOut() {
                vm.employeeData = "";
                employeeGetSet.setEmployeeData(vm.employeeData);
                $state.go('root.home');
            }
            function successResponse(serviceData) {
                vm.reviewQuestion = serviceData;
                console.log(vm.reviewQuestion);
                for (var x in vm.reviewQuestion){
                    vm.reviewQuestion.hasOwnProperty(x) && vm.res.push(vm.reviewQuestion[x]);
                }
                console.log(vm.res);
            }            
        }
    })
();