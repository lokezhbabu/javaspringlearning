(function() {
    "use strict";
    angular
      .module("appraisalReview")
      .service("loginService", loginService);
  
    loginService.$inject = ["$http", "$q"];

    function loginService($http, $q) {
        var service = {
            checkUserCredentials: checkUserCredentials
        };
        return service;

        function checkUserCredentials(UserCredentials) {
            var base_url = "http://localhost:8080/appraisalweb-service/login";
            return $http({
                method: 'POST',
                url: base_url + '/loginCredentials',
                data: UserCredentials
              }).then(sucessCallback)
                .catch(errorCallback);
            }
        function sucessCallback(successResponse) {
            return successResponse.data;
        }

        function errorCallback(errorResponse) {
            alert("Error");
        }
        
    }
})();
