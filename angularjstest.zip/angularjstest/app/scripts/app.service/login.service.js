(function() {
    "use strict";
  
    angular
      .module("appraisalReview")
      .service("loginService", loginService);
  
    loginService.$inject = ["$http", "$q"];

    function loginService($http, $q) {
        var service = {
        };
        return service;

        function checkUserCredentials(UserCredentials) {
            var base_url = "";
            return $http({
                method: 'POST',
                url: base_url + '/getReviewData',
                data: UserCredentials
              }).then(function successCallback(response) {
                  // this callback will be called asynchronously
                  // when the response is available
                  return response.data;
                }, function errorCallback(response) {
                  // called asynchronously if an error occurs
                  // or server returns response with an error status.
                  return "failure";
            });
        }

    }
})();