(function () {
    "use strict";
    angular
        .module("appraisalReview")
        .controller("loginController", loginController);

        loginController.$inject = ["loginService","employeeGetSet", "$state"];
        function loginController (loginService,employeeGetSet, $state) {
            var vm =  this;
            vm.checkUserCredentials = checkUserCredentials; 
            vm.check = "Controller via module is loaded";
            vm.employeeData = "";

            function checkUserCredentials(username,password) {
                var loginCredentials = {
                    username: username,
                    password: password 
                };
                console.log(loginCredentials);
                loginService.checkUserCredentials(loginCredentials)
                .then(successResponse);     
            }
            function successResponse (serviceResponse) {
                console.log(serviceResponse);
                vm.employeeData = serviceResponse;
                employeeGetSet.setEmployeeData(vm.employeeData);
                if(vm.employeeData.username == vm.employeeData.l1) {
                    $state.go('root.admin');
                }
                else {
                    $state.go('root.employee');
                }
            }
        }
    })
();