(function() {
    "use strict";
    angular
      .module("appraisalReview")
      .service("employeeGetSet", employeeGetSet);
  
      employeeGetSet.$inject = [];

    function employeeGetSet() {
        var service = {
            employeeData: "",
            setEmployeeData: setEmployeeData,
            getEmployeeData: getEmployeeData
        };
        return service;

        function setEmployeeData(emplData) {
            this.employeeData = emplData;
        }

        function getEmployeeData() {
            return this.employeeData;
        }
    }
})();