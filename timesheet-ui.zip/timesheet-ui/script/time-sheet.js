$(document).ready(function () {
    var generateTimeSheet = function () {
        var timeEntrySheet = '<tr>' +
            '<td><input type="date" , class="form-control" ,id="date" , placeholder="Data" /></td>' +
            '<td><input type="time" class="form-control" ,id="startTime" , placeholder="Start Time" /></td>' +
            '<td><input type="time" class="form-control" ,id="endTime" , placeholder="End Time" /></td>' +
            '<td><input type="text" class="form-control" ,id="task" , placeholder="Task" /></td>' +
            '<td><input type="text" class="form-control" ,id="description" , placeholder="Task Description" /></td>' +
            '</tr>'
        $('#entryTableBody').append(timeEntrySheet);
    }

    $('#addRow').on('click', function () {
        generateTimeSheet();
    });

    $('#getTableData').on('click', function () {
        var table = $("#table").clone();    
        var data = [];    
        table.find('tr').each(function (rowIndex, r) {        
            var cols = [];        
            $(this).find('th,td').each(function (colIndex, c) {
                console.log(c + 'sdf' + 'colIndex');
                if (c.nodeName == "TH") {
                    cols.push(c.textContent)
                } else {
                    cols.push(c.childNodes[0].value);
                }         
            });        
            data.push(cols);    
        });
        ohSnap('Yeeaahh! You have saved', {'duration':'2000',color: 'green'});
    });

    $('#cancelProcess').on('click', function() {
        location.reload();
        ohSnap('Process is canceled successfully', {'duration':'2000',color: 'red'} );
    });

    $('#ResetProcess').on('click', function() {
        location.reload();
        ohSnap('Process is reset successfully', {'duration':'2000',color: 'red'} );
    });

    $('#logout').on('click', function() {
        sessionStorage.clear();
        window.close();
    })
    generateTimeSheet();
});