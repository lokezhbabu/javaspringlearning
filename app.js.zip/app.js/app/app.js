angular
    .module('appraisalReview', ["ui.router"])
    .config(RunConfig);

RunConfig.$inject = ['$stateProvider', '$urlRouterProvider', '$locationProvider'];

function RunConfig($stateProvider, $urlRouterProvider, $locationProvider) {
    $locationProvider
        .hashPrefix('!');
    $stateProvider
    .state('root', {
        abstract: true, 
        // must be a parent state
        // a state that cannot be activated directly (via transitionTo) without activating one of its children.
        // must have a default child state (either with empty url or default property)
        // if no default child state is set, first child state found will be used as default
        // can be navigated to via url, but this really just activates default child state
        url: ''
    })
    .state('root.home', {
        url: '/login',
        controller: 'loginController',
        templateUrl: './view/login.html',
    })
    .state('root.admin', {
        url: '/dashbaord-admin',
        controller: 'adminController',
        templateUrl: './view/adminPage.html'
    })
    .state('root.employee', {
        url: '/dashbaord-employee',
        controller: 'employeeController',
        templateUrl: './view/employeePage.html'
    })
    .state('root.error', {
        url: '/error',
        template: `<fieldset>
                    <legend>Error</legend>
                    <div> Something went wrong in URL
                        <p>
                            try <a ui-sref="root.home">Login</a> page 
                        </p>
                      </div>
                  </fieldset>`
    });
    $urlRouterProvider.otherwise("/error");
}
