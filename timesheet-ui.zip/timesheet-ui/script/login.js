$(document).ready(function(){
    $('#submitButton').on('click', function() {
        var email = $("#email").val();
        var password = $("#password").val();
        var loginDetails = {
            email : email,
            password: password
        }
        if(email == "admin@admin.com" && password == "admin123"){
            sessionStorage.setItem('userData', JSON.stringify(loginDetails));
            window.open("time-sheet.dashboard.html");
        }
    });
});
