(function () {
    "use strict";
    angular
        .module("appraisalReview")
        .controller("adminController", adminController);

        adminController.$inject = ["employeeGetSet", "$state"];
        function adminController (employeeGetSet, $state) {
            var vm =  this;
            vm.check = "adminController via module is loaded";
            vm.getServiceData = getServiceData;
            vm.employeeData = "";

            getServiceData();

            function getServiceData() {
                vm.employeeData = employeeGetSet.getEmployeeData();
                console.log(vm.employeeData);
            }
        }
    })
();