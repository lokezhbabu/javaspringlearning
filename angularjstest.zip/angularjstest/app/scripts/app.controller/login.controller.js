(function () {
    "use strict";
    angular
        .module("appraisalReview")
        .controller("loginController", loginController);

        loginController.$inject = [""];
        function loginController () {
            var vm =  this; 
            vm.check = "Controller via module is loaded";
            vm.checkUserLogin = checkUserLogin;

            function checkUserCredentials(username,password) {
                var loginCredentials = {
                    username: username,
                    password: password 
                };
            }
        }
})();