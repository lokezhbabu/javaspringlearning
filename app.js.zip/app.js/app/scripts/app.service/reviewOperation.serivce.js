(function() {
    "use strict";
    angular
      .module("appraisalReview")
      .service("reviewOperation", reviewOperation);
  
      reviewOperation.$inject = ["$http", "$q"];

    function reviewOperation($http, $q) {
        var service = {
            getReviewQuestion: getReviewQuestion
        };
        return service;

        function getReviewQuestion() {
            var base_url = "http://localhost:8080/appraisalweb-service/review";
            return $http({
                method: 'GET',
                url: base_url + '/getReviewData',
              }).then(sucessCallback)
                .catch(errorCallback);
            }
        function sucessCallback(successResponse) {
            return successResponse.data;
        }

        function errorCallback(errorResponse) {
            alert("Error");
        }
    }
})();
